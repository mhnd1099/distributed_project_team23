<script>
	import Header from "./components/Header.svelte";
	import SideNav from "./components/SideNav.svelte";
	import CodeEditor from "./components/CodeEditor.svelte";
  </script>
  
  <Header />
  <div class="wrapper">
	<CodeEditor />
	<SideNav />
  </div>
  <style>
	.wrapper{
		display: flex;
		height: 90%;


}

  </style>
