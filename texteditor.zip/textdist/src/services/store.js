import {writable} from "svelte/store";
export const EditorStore = writable(null);