<script>
    import {downloadCodeFromEditor} from "../services/codeeditor.service";
    const downloadCode = () => {

        downloadCodeFromEditor("Code.txt");

    };
</script>

<div class = "side-bar">
<i on:click {downloadCode} class="fa fa-download icons"></i>
<i on:click={() => (window.location.href = "/")} class="fa fa-plus icons"></i>
</div>
<style>
    .side-bar{
        display: flex;
            flex-direction: column;
            background-color: white;
    }
    .icons{
        font-size: 20px;
        padding: 10px;
        color: black;
        border-bottom: 2px solid black ;
}
.icons:hover{
    cursor:pointer;

}
</style>