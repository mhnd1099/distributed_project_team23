<script>
    //export let imageSrc;
  </script>
  
  <header>
    <!--<img src={imageSrc} alt="Logo" />-->
  </header>
  
  <style>
    header {
      height: 10%;
      width: 100%;
      background: black;
    }
    header img {
      height: 0%;
    }
  </style>